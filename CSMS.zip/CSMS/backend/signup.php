<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['UserRole'])) {
    include 'db.php';

    // Retrieve form data and sanitize input
    $firstName = isset($_POST['firstname']) ? trim($_POST['firstname']) : '';
    $lastName = isset($_POST['lastname']) ? trim($_POST['lastname']) : '';
    $email = isset($_POST['email']) ? filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL) : '';
    $collegeDepartment = isset($_POST['collegedepartmentname']) ? trim($_POST['collegedepartmentname']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';  // Password is not hashed
    $userRole = isset($_POST['UserRole']) ? trim($_POST['UserRole']) : '';
    $phoneNumber = isset($_POST['phoneNumber']) ? trim($_POST['phoneNumber']) : '';

    // Validate input data
    if (empty($firstName) || empty($lastName) || empty($email) || empty($collegeDepartment) || empty($password) || empty($userRole) || empty($phoneNumber)) {
        echo "<div class='error'>All fields are required.</div>";
        return;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<div class='error'>Invalid email format.</div>";
        return;
    }

    // Check for duplicate email in tblusers
    $stmt = $conn->prepare("SELECT * FROM tblusers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo "<div class='error'>Email already exists.</div>";
        return;
    }
    $stmt->close();

    // Insert user into the tblusers table with plain text password
    $stmt = $conn->prepare("INSERT INTO tblusers (Email, Password, UserRole) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $password, $userRole);  // Storing password as plain text

    if (!$stmt->execute()) {
        // Print detailed MySQL error
        echo "<div class='error'>Error occurred during signup: " . $stmt->error . "</div>";
        return;
    }

    // Insert user into the tblUserRole table
    $stmt = $conn->prepare("INSERT INTO tblusers ( UserRole) VALUES (?)");
    $stmt->bind_param("s", $userRole); 
    
    if (!$stmt->execute()) {
        // Print detailed MySQL error
        echo "<div class='error'>Error occurred during signup: " . $stmt->error . "</div>";
        return;
    }


    // Get the last inserted User_ID from tblusers
    $userID = $conn->insert_id;

    // Now insert the user data into the Applicants table
    $stmt = $conn->prepare("INSERT INTO tblapplicants (User_ID, CollegeDep_ID, FirstName, LastName, PhoneNumber, Email) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $userID, $collegeDepartment, $firstName, $lastName, $phoneNumber, $email);
    
    if ($stmt->execute()) {
        echo "<div class='success'>Signup successful, and application submitted!</div>";
    } else {
        echo "<div class='error'>Error occurred while inserting into Applicants table: " . $stmt->error . "</div>";
    }

    $stmt->close();
}
?>
