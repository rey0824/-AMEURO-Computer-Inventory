<?php

include 'db.php'; // Ensure this is the correct path to your db.php file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $response = array();

    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $userRole = $_POST['userRole'] ?? '';

    if (empty($email)) {
        $response['status'] = 'error';
        $response['message'] = 'Email is required.';
        echo json_encode($response);
        return;
    }

    if (empty($password)) {
        $response['status'] = 'error';
        $response['message'] = 'Password is required.';
        echo json_encode($response);
        return;
    }

    // Ensure $conn is a valid database connection
    if ($conn->connect_error) {
        $response['status'] = 'error';
        $response['message'] = 'Database connection failed: ' . $conn->connect_error;
        echo json_encode($response);
        return;
    }

    // Prepare the SQL statement
    $stmt = $conn->prepare("SELECT email, Password FROM tblusers WHERE email = ?");

    if ($stmt === false) {
        $response['status'] = 'error';
        $response['message'] = 'Failed to prepare the SQL statement: ' . $conn->error;
        echo json_encode($response);
        return;
    }


    // Check if prepare() returned false
    if ($stmt === false) {
        $response['status'] = 'error';
        $response['message'] = 'Failed to prepare the SQL statement. ' . $conn->error;
        echo json_encode($response);
        return;
    }


    // Bind the parameter and execute the statement
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows == 0) {
        $response['status'] = 'error';
        $response['message'] = 'User not found.';
        echo json_encode($response);
        return;
    }

    $user = $result->fetch_assoc();

    // Verify password (if you store plain text passwords)
    if ($password === $user['Password']) {
        // Success response
        $response['status'] = 'success';
        $response['message'] = 'Login successful.';
        echo json_encode($response);

        // Redirect to dashboard
        header("Location: http://localhost/CSMS/frontend/dashboard.html");
        exit(); // Make sure to exit after a redirect
    } else {
        // Incorrect password
        $response['status'] = 'error';
        $response['message'] = 'Invalid password.';
        echo json_encode($response);


    }
}
?>