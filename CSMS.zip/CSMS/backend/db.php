<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "csms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error, 0); // Logs the error
    echo "<div class='error'>Database connection failed. Please try again later.</div>";
    exit; // Gracefully exit the script
}

// Optional: You can also set the charset for your connection
$conn->set_charset("utf8");
?>
