-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2024 at 03:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `csms`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblapplicants`
--

CREATE TABLE `tblapplicants` (
  `Applicants_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `CollegeDep_ID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `PhoneNumber` varchar(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `ApplicationForm` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblapplications`
--

CREATE TABLE `tblapplications` (
  `Application_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Applicant_ID` int(11) NOT NULL,
  `Scholarship_ID` int(11) NOT NULL,
  `SubmissionDate` date NOT NULL,
  `Status` varchar(50) NOT NULL,
  `ReviewDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblappnotif`
--

CREATE TABLE `tblappnotif` (
  `AppNotif_ID` int(11) NOT NULL,
  `Application_ID` int(11) NOT NULL,
  `Notification_ID` int(11) NOT NULL,
  `SentDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcollegedepartment`
--

CREATE TABLE `tblcollegedepartment` (
  `CollegeDep_ID` int(11) NOT NULL,
  `DepartmentName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcollegedepartment`
--

INSERT INTO `tblcollegedepartment` (`CollegeDep_ID`, `DepartmentName`) VALUES
(1, 'College of Computer Studies'),
(2, 'College of Architecture');

-- --------------------------------------------------------

--
-- Table structure for table `tblnotifications`
--

CREATE TABLE `tblnotifications` (
  `Notification_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `NotificationType` varchar(50) NOT NULL,
  `Message` text NOT NULL,
  `SentDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblscholarships`
--

CREATE TABLE `tblscholarships` (
  `Scholarship_ID` int(11) NOT NULL,
  `ScholarshipName` varchar(50) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Description` text NOT NULL,
  `Eligibility` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblscholarships`
--

INSERT INTO `tblscholarships` (`Scholarship_ID`, `ScholarshipName`, `Category`, `Type`, `Description`, `Eligibility`) VALUES
(1, 'Entrance Scholarship', 'Internal', 'Academic', '[Description]', '[Eligibility]'),
(2, 'Dean\'s List', 'Internal', 'Academic', '[Description]', '[Eligibility]'),
(3, 'Supreme Student Council', 'Internal', 'Co-Curricular', '[Description]', '[Eligibility]'),
(4, 'The Perpetualite Archives', 'Internal', 'Co-Curricular', '[Description]', '[Eligibility]'),
(5, 'College Council Presidents', 'Internal', 'Co-Curricular', '[Description]', '[Eligibility]'),
(6, 'Presidential/Board of Directors Scholars', 'Internal', 'Co-Curricular', '[Description]', '[Eligibility]'),
(7, 'Student Assistantship Program', 'Internal', 'Co-Curricular', '[Description]', '[Eligibility]'),
(8, 'Government', 'External', '', '[Description]', '[Eligibility]'),
(9, 'Private', 'External', '', '[Description]', '[Eligibility]');

-- --------------------------------------------------------

--
-- Table structure for table `tbluserrole`
--

CREATE TABLE `tbluserrole` (
  `UserRole_ID` int(11) NOT NULL,
  `TypeofRole` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbluserrole`
--

INSERT INTO `tbluserrole` (`UserRole_ID`, `TypeofRole`) VALUES
(1, 'Admin'),
(2, 'Dean'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `User_ID` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `UserRole` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`User_ID`, `Email`, `Password`, `UserRole`) VALUES
(1, 'admin@gmail.com', '11111', 1),
(2, 'dean@gmail.com', '11111', 2),
(3, 'user@gmail.com', '11111', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblapplicants`
--
ALTER TABLE `tblapplicants`
  ADD PRIMARY KEY (`Applicants_ID`);

--
-- Indexes for table `tblapplications`
--
ALTER TABLE `tblapplications`
  ADD PRIMARY KEY (`Application_ID`);

--
-- Indexes for table `tblappnotif`
--
ALTER TABLE `tblappnotif`
  ADD PRIMARY KEY (`AppNotif_ID`);

--
-- Indexes for table `tblcollegedepartment`
--
ALTER TABLE `tblcollegedepartment`
  ADD PRIMARY KEY (`CollegeDep_ID`);

--
-- Indexes for table `tblnotifications`
--
ALTER TABLE `tblnotifications`
  ADD PRIMARY KEY (`Notification_ID`);

--
-- Indexes for table `tblscholarships`
--
ALTER TABLE `tblscholarships`
  ADD PRIMARY KEY (`Scholarship_ID`);

--
-- Indexes for table `tbluserrole`
--
ALTER TABLE `tbluserrole`
  ADD PRIMARY KEY (`UserRole_ID`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcollegedepartment`
--
ALTER TABLE `tblcollegedepartment`
  MODIFY `CollegeDep_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblscholarships`
--
ALTER TABLE `tblscholarships`
  MODIFY `Scholarship_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbluserrole`
--
ALTER TABLE `tbluserrole`
  MODIFY `UserRole_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
